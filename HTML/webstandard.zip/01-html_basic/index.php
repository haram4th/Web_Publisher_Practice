<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>php</title>
</head>
<body>
	
<?php
	
	echo "<p>Hello World</p>";

?>

</body>
</html>